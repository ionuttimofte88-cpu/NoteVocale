# Note Vocale AI (Android)

Înregistrează discuții, le transcrie în română, identifică vorbitorii după voce
(Vorbitor 1, Vorbitor 2…), face rezumat cu AI și pune întâlnirile stabilite direct
în calendarul Google de pe telefon.

## Funcții
- Înregistrare cu **Pauză / Continuă / Stop** (merge și cu ecranul blocat)
- După oprire: **Continuă dialogul** (segment nou) sau **Adaugă notă** scrisă
- Transcriere în română + **identificarea vorbitorilor** (AssemblyAI)
- **Rezumat AI** în română: puncte cheie, decizii, acțiuni de urmat (Claude)
- **Întâlnirile stabilite** („ne vedem joi la 3”) sunt adăugate automat în Google Calendar, cu memento
- Partajare discuție (rezumat + transcriere), copiere rezumat, istoric discuții

## Cum o instalezi
1. Instalează **Android Studio** (gratuit): https://developer.android.com/studio
2. Dezarhivează proiectul și deschide folderul `NoteVocale` în Android Studio (File → Open).
3. Așteaptă sincronizarea Gradle (prima dată descarcă dependențele).
4. Conectează telefonul prin USB cu „Depanare USB” activată
   (Setări → Despre telefon → apasă de 7 ori pe „Număr versiune” → Opțiuni dezvoltator → Depanare USB).
5. Apasă butonul ▶ Run. Sau Build → Build APK(s) și copiezi APK-ul pe telefon.

## Chei API (în aplicație → Setări)
- **AssemblyAI** (transcriere + vorbitori): https://www.assemblyai.com → API Keys
- **Claude / Anthropic** (rezumat + întâlniri): https://console.anthropic.com → API Keys

Ambele servicii se plătesc după consum (AssemblyAI oferă credit gratuit la început).
Cheile sunt salvate local pe telefon.

## Note
- Etichetele „Vorbitor 1/2” sunt atribuite separat în fiecare segment. AI-ul încearcă să-i
  coreleze din context în rezumat.
- Dacă știi câți vorbitori sunt, setează numărul în Setări: identificarea e mai precisă.
- Calendarul: evenimentele sunt scrise în calendarul principal al contului Google de pe telefon
  și se sincronizează automat. Dacă refuzi permisiunea, le poți adăuga manual din lista
  „Întâlniri stabilite”.
- Audio-ul este trimis către AssemblyAI, iar textul către Anthropic pentru procesare.
  Cere acordul participanților înainte să înregistrezi.
