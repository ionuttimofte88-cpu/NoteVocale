package ro.notevocale.net

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/** Generează rezumatul discuției în română cu Claude (Anthropic Messages API). */
class ClaudeClient(private val apiKey: String, private val model: String) {

    private val http = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(5, TimeUnit.MINUTES)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    suspend fun summarize(transcript: String): String =
        ask(SYSTEM_PROMPT, "Iată discuția de analizat:\n\n$transcript", 4000)

    /**
     * Extrage întâlnirile stabilite în discuție. Întoarce un JSON array (ca text).
     * referenceInfo = data/ora discuției, pentru a rezolva expresii ca „joi viitoare”.
     */
    suspend fun extractMeetings(transcript: String, referenceInfo: String): String {
        val raw = ask(
            MEETINGS_PROMPT,
            "$referenceInfo\n\nDiscuția:\n\n$transcript",
            1500
        )
        val start = raw.indexOf('[')
        val end = raw.lastIndexOf(']')
        return if (start >= 0 && end > start) raw.substring(start, end + 1) else "[]"
    }

    private suspend fun ask(system: String, user: String, maxTokens: Int): String = withContext(Dispatchers.IO) {
        val payload = JSONObject()
            .put("model", model)
            .put("max_tokens", maxTokens)
            .put("system", system)
            .put(
                "messages", JSONArray().put(
                    JSONObject()
                        .put("role", "user")
                        .put("content", user)
                )
            )

        val req = Request.Builder()
            .url("https://api.anthropic.com/v1/messages")
            .header("x-api-key", apiKey)
            .header("anthropic-version", "2023-06-01")
            .post(payload.toString().toRequestBody("application/json".toMediaType()))
            .build()

        http.newCall(req).execute().use { r ->
            val body = r.body?.string().orEmpty()
            if (!r.isSuccessful) {
                val msg = runCatching {
                    JSONObject(body).getJSONObject("error").getString("message")
                }.getOrDefault(body.take(300))
                throw IOException("Eroare AI (${r.code}): $msg")
            }
            val content = JSONObject(body).getJSONArray("content")
            buildString {
                for (i in 0 until content.length()) {
                    val block = content.getJSONObject(i)
                    if (block.optString("type") == "text") append(block.getString("text"))
                }
            }.trim()
        }
    }

    companion object {
        private val SYSTEM_PROMPT = """
            Ești un asistent care analizează transcrieri de discuții în limba română.
            Primești transcrierea automată a uneia sau mai multor înregistrări (segmente) și,
            eventual, notițe scrise de utilizator. Vorbitorii au fost identificați automat după voce
            ca „Vorbitor 1”, „Vorbitor 2” etc.

            Important:
            - Etichetele vorbitorilor sunt atribuite separat în fiecare segment. „Vorbitor 1” din
              segmentul 2 poate fi altă persoană decât „Vorbitor 1” din segmentul 1. Dacă din context
              reiese cine este cine (nume, rol, ce spune), corelează-i; altfel menționează incertitudinea.
            - Transcrierea automată poate conține greșeli de recunoaștere; interpretează cu bun simț.
            - Notițele utilizatorului sunt informații importante, ține cont de ele.
            - Nu inventa informații care nu apar în discuție.

            Răspunde DOAR în limba română, în format Markdown simplu, cu secțiunile:
            ## Rezumat
            ## Participanți
            (ce a susținut fiecare vorbitor; dacă un nume apare în discuție, folosește-l)
            ## Puncte cheie
            ## Decizii luate
            ## Acțiuni de urmat
            (cine, ce, termen – dacă e menționat)
            ## Întrebări deschise
            Omite secțiunile pentru care nu există conținut.
        """.trimIndent()

        private val MEETINGS_PROMPT = """
            Analizezi o discuție în limba română și extragi DOAR întâlnirile sau evenimentele viitoare
            care au fost stabilite concret (au o zi convenită). Nu include propuneri respinse,
            idei vagi („cândva săptămâna viitoare”) sau evenimente din trecut.
            Rezolvă datele relative („mâine”, „joi viitoare”, „pe 3”) folosind data discuției primită.

            Răspunde EXCLUSIV cu un array JSON valid, fără alt text, de forma:
            [{"titlu":"...","inceput":"YYYY-MM-DDTHH:MM","durata_minute":60,"toata_ziua":false,"locatie":"","detalii":"cine participă, scopul"}]
            - Dacă nu s-a stabilit ora: "toata_ziua": true și "inceput": "YYYY-MM-DDT00:00".
            - Dacă nu s-a stabilit durata: 60.
            - Titlul scurt, în română.
            - Dacă nu există nicio întâlnire stabilită: []
        """.trimIndent()
    }
}
