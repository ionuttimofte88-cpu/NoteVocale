package ro.notevocale.rec

import android.content.Context
import android.media.MediaRecorder
import android.os.Build
import android.os.SystemClock
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File

/** Gestionează înregistrarea audio (start / pauză / continuare / stop). */
object RecorderManager {

    enum class State { IDLE, RECORDING, PAUSED }

    private val _state = MutableStateFlow(State.IDLE)
    val state = _state.asStateFlow()

    private val _elapsed = MutableStateFlow(0L)
    val elapsed = _elapsed.asStateFlow()

    private var recorder: MediaRecorder? = null
    private var file: File? = null
    private var accumulated = 0L
    private var segmentStart = 0L
    private var ticker: Job? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    fun start(context: Context, output: File) {
        check(recorder == null) { "O înregistrare este deja în curs" }
        val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(context)
        else @Suppress("DEPRECATION") MediaRecorder()
        try {
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioChannels(1)
            r.setAudioSamplingRate(44100)
            r.setAudioEncodingBitRate(96_000)
            r.setOutputFile(output.absolutePath)
            r.prepare()
            r.start()
        } catch (e: Exception) {
            r.release()
            output.delete()
            throw e
        }
        recorder = r
        file = output
        accumulated = 0
        segmentStart = SystemClock.elapsedRealtime()
        _state.value = State.RECORDING
        ticker?.cancel()
        ticker = scope.launch {
            while (isActive) {
                _elapsed.value = currentElapsed()
                delay(250)
            }
        }
    }

    fun pause() {
        if (_state.value != State.RECORDING) return
        recorder?.pause()
        accumulated += SystemClock.elapsedRealtime() - segmentStart
        _state.value = State.PAUSED
    }

    fun resume() {
        if (_state.value != State.PAUSED) return
        recorder?.resume()
        segmentStart = SystemClock.elapsedRealtime()
        _state.value = State.RECORDING
    }

    /** Oprește înregistrarea. Întoarce fișierul și durata, sau null dacă a fost prea scurtă. */
    fun stop(): Pair<File, Long>? {
        val r = recorder ?: return null
        val f = file
        val duration = currentElapsed()
        val ok = try {
            r.stop(); true
        } catch (e: RuntimeException) {
            false
        }
        r.release()
        recorder = null
        file = null
        ticker?.cancel()
        _state.value = State.IDLE
        _elapsed.value = 0
        if (!ok || f == null) {
            f?.delete()
            return null
        }
        return f to duration
    }

    private fun currentElapsed(): Long =
        accumulated + if (_state.value == State.RECORDING) SystemClock.elapsedRealtime() - segmentStart else 0
}
