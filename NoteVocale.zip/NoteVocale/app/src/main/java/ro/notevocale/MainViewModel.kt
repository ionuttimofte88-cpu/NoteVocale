package ro.notevocale

import android.app.Application
import android.content.Intent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import ro.notevocale.calendar.CalendarHelper
import ro.notevocale.data.Item
import ro.notevocale.data.Meeting
import ro.notevocale.data.Prefs
import ro.notevocale.data.ProcStatus
import ro.notevocale.data.Session
import ro.notevocale.data.SessionStore
import ro.notevocale.net.AssemblyAiClient
import ro.notevocale.net.ClaudeClient
import ro.notevocale.rec.RecorderManager
import ro.notevocale.rec.RecordingService
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

sealed interface Screen {
    data object Home : Screen
    data class Detail(val id: String) : Screen
    data object Settings : Screen
}

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val store = SessionStore(app)
    val prefs = Prefs(app)

    private val _sessions = MutableStateFlow(store.loadAll())
    val sessions = _sessions.asStateFlow()

    val recState = RecorderManager.state
    val elapsed = RecorderManager.elapsed

    var screen by mutableStateOf<Screen>(Screen.Home)
    var recordingSessionId by mutableStateOf<String?>(null)
        private set
    var summarizingId by mutableStateOf<String?>(null)
        private set
    var message by mutableStateOf<String?>(null)

    init {
        // Transcrieri întrerupte (aplicația a fost închisă) -> pot fi reluate.
        _sessions.value.forEach { s ->
            if (s.items.any { it is Item.Recording && it.status == ProcStatus.PROCESSING }) {
                update(s.id) { sess ->
                    sess.copy(items = sess.items.map {
                        if (it is Item.Recording && it.status == ProcStatus.PROCESSING)
                            it.copy(status = ProcStatus.ERROR, error = "Transcriere întreruptă. Apasă „Reîncearcă”.")
                        else it
                    })
                }
            }
        }
    }

    // ---------- Discuții ----------

    fun session(id: String) = _sessions.value.find { it.id == id }

    private fun update(id: String, f: (Session) -> Session) {
        val s = session(id) ?: return
        val n = f(s)
        store.save(n)
        _sessions.value = _sessions.value.map { if (it.id == id) n else it }
    }

    fun newSession() {
        val now = System.currentTimeMillis()
        val title = "Discuție " + SimpleDateFormat("d MMM yyyy, HH:mm", Locale("ro")).format(Date(now))
        val s = Session(UUID.randomUUID().toString(), title, now, emptyList(), null)
        store.save(s)
        _sessions.value = listOf(s) + _sessions.value
        screen = Screen.Detail(s.id)
    }

    fun open(id: String) {
        screen = Screen.Detail(id)
    }

    fun rename(id: String, title: String) {
        if (title.isNotBlank()) update(id) { it.copy(title = title.trim()) }
    }

    fun deleteSession(id: String) {
        if (recordingSessionId == id) stopRecording()
        val s = session(id) ?: return
        store.delete(s)
        _sessions.value = _sessions.value.filterNot { it.id == id }
        screen = Screen.Home
    }

    // ---------- Înregistrare ----------

    fun startRecording(sessionId: String) {
        if (recState.value != RecorderManager.State.IDLE) return
        val ctx = getApplication<Application>()
        val file = File(store.audioDir, "${UUID.randomUUID()}.m4a")
        val serviceIntent = Intent(ctx, RecordingService::class.java)
        try {
            ContextCompat.startForegroundService(ctx, serviceIntent)
            RecorderManager.start(ctx, file)
            recordingSessionId = sessionId
        } catch (e: Exception) {
            ctx.stopService(serviceIntent)
            message = "Nu pot porni înregistrarea: ${e.message}"
        }
    }

    fun pauseRecording() = RecorderManager.pause()
    fun resumeRecording() = RecorderManager.resume()

    fun stopRecording() {
        val ctx = getApplication<Application>()
        val result = RecorderManager.stop()
        ctx.stopService(Intent(ctx, RecordingService::class.java))
        val sessionId = recordingSessionId ?: return
        recordingSessionId = null
        if (result == null) {
            message = "Înregistrarea a fost prea scurtă și nu a fost salvată."
            return
        }
        val item = Item.Recording(
            id = UUID.randomUUID().toString(),
            createdAt = System.currentTimeMillis(),
            filePath = result.first.absolutePath,
            durationMs = result.second,
            status = ProcStatus.PENDING,
        )
        update(sessionId) { it.copy(items = it.items + item) }
        transcribe(sessionId, item.id)
    }

    // ---------- Transcriere ----------

    private fun updateRecording(sessionId: String, itemId: String, f: (Item.Recording) -> Item.Recording) =
        update(sessionId) { s ->
            s.copy(items = s.items.map { if (it is Item.Recording && it.id == itemId) f(it) else it })
        }

    fun transcribe(sessionId: String, itemId: String) {
        val key = prefs.assemblyKey
        if (key.isBlank()) {
            updateRecording(sessionId, itemId) {
                it.copy(status = ProcStatus.ERROR, error = "Lipsește cheia AssemblyAI. Adaug-o în Setări, apoi apasă „Reîncearcă”.")
            }
            return
        }
        val rec = session(sessionId)?.items?.find { it.id == itemId } as? Item.Recording ?: return
        updateRecording(sessionId, itemId) { it.copy(status = ProcStatus.PROCESSING, error = null) }
        viewModelScope.launch {
            try {
                val utterances = AssemblyAiClient(key, prefs.speakersExpected).transcribe(File(rec.filePath))
                updateRecording(sessionId, itemId) {
                    it.copy(status = ProcStatus.DONE, utterances = utterances, error = null)
                }
            } catch (e: Exception) {
                updateRecording(sessionId, itemId) {
                    it.copy(status = ProcStatus.ERROR, error = e.message ?: "Eroare necunoscută")
                }
            }
        }
    }

    // ---------- Note ----------

    fun addNote(sessionId: String, text: String) {
        if (text.isBlank()) return
        val note = Item.Note(UUID.randomUUID().toString(), System.currentTimeMillis(), text.trim())
        update(sessionId) { it.copy(items = it.items + note) }
    }

    fun editNote(sessionId: String, itemId: String, text: String) {
        if (text.isBlank()) return
        update(sessionId) { s ->
            s.copy(items = s.items.map { if (it is Item.Note && it.id == itemId) it.copy(text = text.trim()) else it })
        }
    }

    fun deleteItem(sessionId: String, itemId: String) {
        update(sessionId) { s ->
            s.items.find { it.id == itemId }?.let { if (it is Item.Recording) File(it.filePath).delete() }
            s.copy(items = s.items.filterNot { it.id == itemId })
        }
    }

    // ---------- Rezumat AI ----------

    fun summarize(sessionId: String) {
        val s = session(sessionId) ?: return
        val key = prefs.claudeKey
        if (key.isBlank()) {
            message = "Lipsește cheia Claude (Anthropic). Adaug-o în Setări."
            return
        }
        if (s.items.any { it is Item.Recording && it.status == ProcStatus.PROCESSING }) {
            message = "Așteaptă să se termine transcrierea înainte de rezumat."
            return
        }
        val text = transcriptText(s)
        if (text.isBlank()) {
            message = "Nu există încă text de rezumat. Înregistrează sau adaugă o notă."
            return
        }
        summarizingId = sessionId
        viewModelScope.launch {
            val client = ClaudeClient(key, prefs.model)
            try {
                val summary = client.summarize(text)
                update(sessionId) { it.copy(summary = summary) }
            } catch (e: Exception) {
                message = e.message ?: "Eroare la generarea rezumatului."
                summarizingId = null
                return@launch
            }
            // Întâlniri stabilite -> calendar
            try {
                val json = client.extractMeetings(text, referenceInfo(s.createdAt))
                addMeetings(sessionId, CalendarHelper.parseMeetings(json))
            } catch (e: Exception) {
                message = "Rezumatul e gata, dar întâlnirile nu au putut fi extrase: ${e.message}"
            } finally {
                summarizingId = null
            }
        }
    }

    private fun referenceInfo(createdAt: Long): String {
        val ro = Locale("ro")
        val d = Date(createdAt)
        return "Data discuției: " + SimpleDateFormat("yyyy-MM-dd (EEEE), 'ora' HH:mm", ro).format(d) +
            ", fus orar " + java.util.TimeZone.getDefault().id + "."
    }

    private fun addMeetings(sessionId: String, found: List<Meeting>) {
        val ctx = getApplication<Application>()
        val s = session(sessionId) ?: return
        // Nu dubla întâlnirile deja găsite la un rezumat anterior.
        val fresh = found.filter { f -> s.meetings.none { it.startMs == f.startMs } }
        if (fresh.isEmpty()) return

        val canWrite = CalendarHelper.hasPermission(ctx)
        val added = fresh.map { m ->
            if (canWrite) m.copy(eventId = runCatching { CalendarHelper.insert(ctx, m, s.title) }.getOrNull())
            else m
        }
        update(sessionId) { it.copy(meetings = it.meetings + added) }

        val ok = added.count { it.eventId != null }
        message = when {
            ok == added.size -> "Am adăugat $ok ${if (ok == 1) "întâlnire" else "întâlniri"} în calendar."
            !canWrite -> "Am găsit ${added.size} întâlniri, dar aplicația nu are acces la calendar. " +
                "Le poți adăuga manual din lista de sub rezumat."
            else -> "Am adăugat $ok din ${added.size} întâlniri. Verifică dacă ai un cont Google în Calendar."
        }
    }

    /** Adaugă manual în calendar o întâlnire găsită (după ce s-a acordat permisiunea). */
    fun addMeetingToCalendar(sessionId: String, index: Int) {
        val ctx = getApplication<Application>()
        val s = session(sessionId) ?: return
        val m = s.meetings.getOrNull(index) ?: return
        if (!CalendarHelper.hasPermission(ctx)) {
            CalendarHelper.openInsertScreen(ctx, m)
            return
        }
        val id = runCatching { CalendarHelper.insert(ctx, m, s.title) }.getOrNull()
        if (id == null) {
            message = "Nu am găsit niciun calendar pe telefon. Adaugă un cont Google în aplicația Calendar."
            return
        }
        update(sessionId) { it.copy(meetings = it.meetings.mapIndexed { i, x -> if (i == index) x.copy(eventId = id) else x }) }
    }

    fun removeMeeting(sessionId: String, index: Int) {
        val ctx = getApplication<Application>()
        val m = session(sessionId)?.meetings?.getOrNull(index) ?: return
        m.eventId?.let { if (CalendarHelper.hasPermission(ctx)) CalendarHelper.delete(ctx, it) }
        update(sessionId) { it.copy(meetings = it.meetings.filterIndexed { i, _ -> i != index }) }
    }

    fun openMeeting(eventId: Long) = CalendarHelper.openEvent(getApplication(), eventId)

    /** Textul complet al discuției (segmente + note), în ordine cronologică. */
    fun transcriptText(s: Session): String = buildString {
        var seg = 0
        s.items.forEach { item ->
            when (item) {
                is Item.Recording -> {
                    seg++
                    if (item.status == ProcStatus.DONE && item.utterances.isNotEmpty()) {
                        appendLine("=== Segment de dialog $seg (durată ${formatDuration(item.durationMs)}) ===")
                        item.utterances.forEach { appendLine("${it.speaker}: ${it.text}") }
                        appendLine()
                    }
                }
                is Item.Note -> {
                    appendLine("=== Notă adăugată de utilizator ===")
                    appendLine(item.text)
                    appendLine()
                }
            }
        }
    }.trim()

    fun shareText(s: Session): String = buildString {
        appendLine(s.title)
        appendLine()
        s.summary?.let {
            appendLine(it)
            appendLine()
            if (s.meetings.isNotEmpty()) {
                val f = SimpleDateFormat("EEEE, d MMMM yyyy, HH:mm", Locale("ro"))
                appendLine("ÎNTÂLNIRI STABILITE")
                s.meetings.forEach { m -> appendLine("- ${m.title}: ${f.format(Date(m.startMs))}") }
                appendLine()
            }
            appendLine("------------------------------")
            appendLine("TRANSCRIERE")
            appendLine()
        }
        append(transcriptText(s))
    }
}

fun formatDuration(ms: Long): String {
    val total = ms / 1000
    val h = total / 3600
    val m = (total % 3600) / 60
    val sec = total % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%02d:%02d".format(m, sec)
}
