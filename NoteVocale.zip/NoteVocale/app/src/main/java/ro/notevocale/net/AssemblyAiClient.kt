package ro.notevocale.net

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import ro.notevocale.data.Utterance
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Transcriere în limba română + diarizare (cine vorbește) prin AssemblyAI.
 * Vorbitorii primiți ca "A", "B", "C"... sunt convertiți în "Vorbitor 1", "Vorbitor 2"...
 */
class AssemblyAiClient(private val apiKey: String, private val speakersExpected: Int = 0) {

    private val http = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .writeTimeout(10, TimeUnit.MINUTES)
        .build()

    private val base = "https://api.assemblyai.com/v2"
    private val jsonType = "application/json".toMediaType()

    suspend fun transcribe(file: File): List<Utterance> = withContext(Dispatchers.IO) {
        val uploadUrl = upload(file)
        val id = createTranscript(uploadUrl)
        poll(id)
    }

    private fun upload(file: File): String {
        val req = Request.Builder()
            .url("$base/upload")
            .header("authorization", apiKey)
            .post(file.asRequestBody("application/octet-stream".toMediaType()))
            .build()
        http.newCall(req).execute().use { r ->
            val body = r.body?.string().orEmpty()
            if (!r.isSuccessful) throw IOException("Încărcarea audio a eșuat (${r.code}): ${errorText(body)}")
            return JSONObject(body).getString("upload_url")
        }
    }

    private fun createTranscript(audioUrl: String): String {
        val payload = JSONObject()
            .put("audio_url", audioUrl)
            .put("language_code", "ro")
            .put("speaker_labels", true)
            .put("punctuate", true)
            .put("format_text", true)
        if (speakersExpected in 1..10) payload.put("speakers_expected", speakersExpected)

        val req = Request.Builder()
            .url("$base/transcript")
            .header("authorization", apiKey)
            .post(payload.toString().toRequestBody(jsonType))
            .build()
        http.newCall(req).execute().use { r ->
            val body = r.body?.string().orEmpty()
            if (!r.isSuccessful) throw IOException("Pornirea transcrierii a eșuat (${r.code}): ${errorText(body)}")
            return JSONObject(body).getString("id")
        }
    }

    private suspend fun poll(id: String): List<Utterance> {
        while (true) {
            delay(3000)
            val req = Request.Builder()
                .url("$base/transcript/$id")
                .header("authorization", apiKey)
                .get()
                .build()
            val json = http.newCall(req).execute().use { r ->
                val body = r.body?.string().orEmpty()
                if (!r.isSuccessful) throw IOException("Eroare la verificarea transcrierii (${r.code}): ${errorText(body)}")
                JSONObject(body)
            }
            when (json.getString("status")) {
                "completed" -> return parse(json)
                "error" -> throw IOException("Transcriere eșuată: ${json.optString("error")}")
            }
        }
    }

    private fun parse(json: JSONObject): List<Utterance> {
        val arr = json.optJSONArray("utterances")
        if (arr == null || arr.length() == 0) {
            val text = json.optString("text").trim()
            return if (text.isEmpty() || text == "null") emptyList()
            else listOf(Utterance("Vorbitor 1", text, 0))
        }
        return (0 until arr.length()).map { i ->
            val u = arr.getJSONObject(i)
            Utterance(
                speaker = speakerName(u.optString("speaker", "A")),
                text = u.optString("text").trim(),
                startMs = u.optLong("start", 0),
            )
        }
    }

    private fun speakerName(label: String): String {
        val c = label.trim().uppercase().firstOrNull() ?: 'A'
        val n = if (c in 'A'..'Z') c - 'A' + 1 else label.toIntOrNull()?.plus(1) ?: 1
        return "Vorbitor $n"
    }

    private fun errorText(body: String): String =
        runCatching { JSONObject(body).optString("error", body) }.getOrDefault(body).take(300)
}
