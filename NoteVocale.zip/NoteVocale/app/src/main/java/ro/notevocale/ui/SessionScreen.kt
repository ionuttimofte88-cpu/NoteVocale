package ro.notevocale.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.NoteAdd
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.EventAvailable
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import ro.notevocale.MainViewModel
import ro.notevocale.Screen
import ro.notevocale.data.Item
import ro.notevocale.data.Meeting
import ro.notevocale.data.ProcStatus
import ro.notevocale.formatDuration
import ro.notevocale.rec.RecorderManager
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

private data class NoteEdit(val itemId: String?, val text: String)

private val speakerColors = listOf(
    Color(0xFF1E88E5), Color(0xFFD81B60), Color(0xFF43A047), Color(0xFFF4511E),
    Color(0xFF8E24AA), Color(0xFF00897B), Color(0xFF6D4C41), Color(0xFF3949AB),
)

private fun speakerColor(name: String): Color {
    val n = name.filter { it.isDigit() }.toIntOrNull() ?: 1
    return speakerColors[(n - 1).mod(speakerColors.size)]
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SessionScreen(vm: MainViewModel, id: String) {
    val sessions by vm.sessions.collectAsStateWithLifecycle()
    val session = sessions.find { it.id == id }
    if (session == null) {
        LaunchedEffect(Unit) { vm.screen = Screen.Home }
        return
    }
    val recState by vm.recState.collectAsStateWithLifecycle()
    val elapsed by vm.elapsed.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current

    var noteDialog by remember { mutableStateOf<NoteEdit?>(null) }
    var renameDialog by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }

    val isRecHere = recState != RecorderManager.State.IDLE && vm.recordingSessionId == id
    val recElsewhere = recState != RecorderManager.State.IDLE && !isRecHere
    val summarizing = vm.summarizingId == id
    val hasRecordings = session.items.any { it is Item.Recording }

    // Permisiuni: microfon (+ notificări pe Android 13+)
    val micPerms = buildList {
        add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
    }.toTypedArray()
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        if (res[Manifest.permission.RECORD_AUDIO] == true) vm.startRecording(id)
        else vm.message = "Fără permisiunea pentru microfon nu pot înregistra."
    }
    val onRecord = {
        val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (granted) vm.startRecording(id) else micLauncher.launch(micPerms)
    }

    // Permisiuni calendar: cerute la primul rezumat; rezumatul se face oricum.
    val calPerms = arrayOf(Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR)
    val calLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        vm.summarize(id)
    }
    val onSummarize = {
        val granted = calPerms.all { ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED }
        if (granted) vm.summarize(id) else calLauncher.launch(calPerms)
    }

    // Numerotarea segmentelor de dialog
    val segNumbers = remember(session.items) {
        var n = 0
        session.items.filterIsInstance<Item.Recording>().associate { it.id to ++n }
    }

    val listState = rememberLazyListState()
    LaunchedEffect(session.items.size) {
        if (session.items.isNotEmpty()) listState.animateScrollToItem(session.items.size - 1)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        session.title,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.clickable { renameDialog = true }
                    )
                },
                navigationIcon = {
                    IconButton(onClick = { vm.screen = Screen.Home }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Înapoi")
                    }
                },
                actions = {
                    IconButton(onClick = {
                        val send = Intent(Intent.ACTION_SEND)
                            .setType("text/plain")
                            .putExtra(Intent.EXTRA_SUBJECT, session.title)
                            .putExtra(Intent.EXTRA_TEXT, vm.shareText(session))
                        ctx.startActivity(Intent.createChooser(send, "Trimite discuția"))
                    }) { Icon(Icons.Default.Share, contentDescription = "Trimite") }
                    IconButton(onClick = { confirmDelete = true }) {
                        Icon(Icons.Default.Delete, contentDescription = "Șterge discuția")
                    }
                }
            )
        },
        bottomBar = {
            Surface(tonalElevation = 3.dp, shadowElevation = 8.dp) {
                Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(12.dp)) {
                    when {
                        isRecHere -> RecordingControls(
                            paused = recState == RecorderManager.State.PAUSED,
                            elapsedMs = elapsed,
                            onPause = vm::pauseRecording,
                            onResume = vm::resumeRecording,
                            onStop = vm::stopRecording,
                        )

                        recElsewhere -> Text(
                            "O înregistrare este în curs în altă discuție.",
                            modifier = Modifier.padding(8.dp)
                        )

                        else -> Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = onRecord,
                                modifier = Modifier.fillMaxWidth().height(56.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F))
                            ) {
                                Icon(Icons.Default.Mic, contentDescription = null)
                                Spacer(Modifier.width(8.dp))
                                Text(if (hasRecordings) "Continuă dialogul (înregistrare nouă)" else "Începe înregistrarea")
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(
                                    onClick = { noteDialog = NoteEdit(null, "") },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.AutoMirrored.Filled.NoteAdd, contentDescription = null)
                                    Spacer(Modifier.width(6.dp))
                                    Text("Adaugă notă")
                                }
                                FilledTonalButton(
                                    onClick = onSummarize,
                                    enabled = !summarizing && session.items.isNotEmpty(),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.AutoAwesome, contentDescription = null)
                                    Spacer(Modifier.width(6.dp))
                                    Text(if (session.summary == null) "Rezumat AI" else "Refă rezumat")
                                }
                            }
                        }
                    }
                }
            }
        }
    ) { pad ->
        LazyColumn(
            state = listState,
            modifier = Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (session.items.isEmpty()) {
                item {
                    Text(
                        "Apasă „Începe înregistrarea”. Poți pune pauză oricând, iar după oprire poți " +
                            "continua dialogul cu o înregistrare nouă sau poți adăuga note scrise. " +
                            "La final, „Rezumat AI” analizează totul, iar întâlnirile stabilite " +
                            "sunt adăugate automat în calendar.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }

            items(session.items, key = { it.id }) { item ->
                when (item) {
                    is Item.Recording -> RecordingCard(
                        rec = item,
                        number = segNumbers[item.id] ?: 0,
                        onRetry = { vm.transcribe(id, item.id) },
                        onDelete = { vm.deleteItem(id, item.id) },
                    )

                    is Item.Note -> NoteCard(
                        note = item,
                        onEdit = { noteDialog = NoteEdit(item.id, item.text) },
                        onDelete = { vm.deleteItem(id, item.id) },
                    )
                }
            }

            if (summarizing) {
                item(key = "loading") {
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 3.dp)
                            Spacer(Modifier.width(12.dp))
                            Text("AI analizează discuția…")
                        }
                    }
                }
            }

            session.summary?.let { summary ->
                item(key = "summary") {
                    Card(
                        Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                    ) {
                        Column(Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.AutoAwesome, contentDescription = null)
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    "Rezumat AI",
                                    style = MaterialTheme.typography.titleMedium,
                                    modifier = Modifier.weight(1f)
                                )
                                IconButton(onClick = {
                                    clipboard.setText(AnnotatedString(summary))
                                }) { Icon(Icons.Default.ContentCopy, contentDescription = "Copiază") }
                            }
                            MarkdownText(summary)
                        }
                    }
                }
            }

            if (session.meetings.isNotEmpty()) {
                item(key = "meetings") {
                    MeetingsCard(
                        meetings = session.meetings,
                        onOpen = { vm.openMeeting(it) },
                        onAdd = { vm.addMeetingToCalendar(id, it) },
                        onRemove = { vm.removeMeeting(id, it) },
                    )
                }
            }
        }
    }

    // ---- Dialoguri ----

    noteDialog?.let { edit ->
        var text by remember(edit) { mutableStateOf(edit.text) }
        AlertDialog(
            onDismissRequest = { noteDialog = null },
            title = { Text(if (edit.itemId == null) "Notă nouă" else "Editează nota") },
            text = {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    placeholder = { Text("Scrie nota sau completează dialogul…") },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 140.dp)
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    if (edit.itemId == null) vm.addNote(id, text) else vm.editNote(id, edit.itemId, text)
                    noteDialog = null
                }, enabled = text.isNotBlank()) { Text("Salvează") }
            },
            dismissButton = { TextButton(onClick = { noteDialog = null }) { Text("Anulează") } }
        )
    }

    if (renameDialog) {
        var title by remember { mutableStateOf(session.title) }
        AlertDialog(
            onDismissRequest = { renameDialog = false },
            title = { Text("Redenumește discuția") },
            text = { OutlinedTextField(value = title, onValueChange = { title = it }, singleLine = true) },
            confirmButton = {
                TextButton(onClick = { vm.rename(id, title); renameDialog = false }) { Text("Salvează") }
            },
            dismissButton = { TextButton(onClick = { renameDialog = false }) { Text("Anulează") } }
        )
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Ștergi discuția?") },
            text = { Text("Înregistrările, transcrierea și rezumatul vor fi șterse definitiv. Evenimentele din calendar rămân.") },
            confirmButton = {
                TextButton(onClick = { confirmDelete = false; vm.deleteSession(id) }) { Text("Șterge") }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Anulează") } }
        )
    }
}

@Composable
private fun RecordingControls(
    paused: Boolean,
    elapsedMs: Long,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onStop: () -> Unit,
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(12.dp).background(
                    if (paused) MaterialTheme.colorScheme.outline else Color(0xFFD32F2F), CircleShape
                )
            )
            Spacer(Modifier.width(8.dp))
            Text(
                (if (paused) "Pauză  " else "Se înregistrează  ") + formatDuration(elapsedMs),
                style = MaterialTheme.typography.titleMedium
            )
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
            FilledTonalButton(onClick = if (paused) onResume else onPause, modifier = Modifier.weight(1f).height(56.dp)) {
                Icon(if (paused) Icons.Default.PlayArrow else Icons.Default.Pause, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text(if (paused) "Continuă" else "Pauză")
            }
            Button(
                onClick = onStop,
                modifier = Modifier.weight(1f).height(56.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F))
            ) {
                Icon(Icons.Default.Stop, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text("Stop")
            }
        }
    }
}

@Composable
private fun RecordingCard(rec: Item.Recording, number: Int, onRetry: () -> Unit, onDelete: () -> Unit) {
    var confirm by remember { mutableStateOf(false) }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Mic, contentDescription = null, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(6.dp))
                Text(
                    "Segment de dialog $number · ${formatDuration(rec.durationMs)}",
                    style = MaterialTheme.typography.titleSmall,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = { confirm = true }) {
                    Icon(Icons.Default.Delete, contentDescription = "Șterge segmentul")
                }
            }
            when (rec.status) {
                ProcStatus.PENDING, ProcStatus.PROCESSING -> Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(8.dp))
                    Text("Se transcrie și se identifică vorbitorii…", style = MaterialTheme.typography.bodyMedium)
                }

                ProcStatus.ERROR -> Column {
                    Text(rec.error ?: "Eroare", color = MaterialTheme.colorScheme.error)
                    TextButton(onClick = onRetry) {
                        Icon(Icons.Default.Refresh, contentDescription = null)
                        Spacer(Modifier.width(4.dp))
                        Text("Reîncearcă")
                    }
                }

                ProcStatus.DONE -> if (rec.utterances.isEmpty()) {
                    Text("Nu s-a detectat vorbire.", style = MaterialTheme.typography.bodyMedium)
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 4.dp)) {
                        rec.utterances.forEach { u ->
                            Column {
                                Text(
                                    "${u.speaker} · ${formatDuration(u.startMs)}",
                                    color = speakerColor(u.speaker),
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.labelLarge
                                )
                                Text(u.text, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                }
            }
        }
    }
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Ștergi segmentul $number?") },
            confirmButton = { TextButton(onClick = { confirm = false; onDelete() }) { Text("Șterge") } },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Anulează") } }
        )
    }
}

@Composable
private fun NoteCard(note: Item.Note, onEdit: () -> Unit, onDelete: () -> Unit) {
    Card(
        Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("📝 Notă", style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                IconButton(onClick = onEdit) { Icon(Icons.Default.Edit, contentDescription = "Editează") }
                IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, contentDescription = "Șterge") }
            }
            Text(note.text, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
private fun MeetingsCard(
    meetings: List<Meeting>,
    onOpen: (Long) -> Unit,
    onAdd: (Int) -> Unit,
    onRemove: (Int) -> Unit,
) {
    val ro = Locale("ro")
    val timeFmt = SimpleDateFormat("EEEE, d MMMM yyyy, HH:mm", ro)
    val dayFmt = SimpleDateFormat("EEEE, d MMMM yyyy", ro).apply { timeZone = TimeZone.getTimeZone("UTC") }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.CalendarMonth, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Întâlniri stabilite", style = MaterialTheme.typography.titleMedium)
            }
            meetings.forEachIndexed { i, m ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(m.title, fontWeight = FontWeight.SemiBold)
                        Text(
                            if (m.allDay) dayFmt.format(Date(m.startMs)) + " (toată ziua)"
                            else timeFmt.format(Date(m.startMs)),
                            style = MaterialTheme.typography.bodySmall
                        )
                        if (m.location.isNotBlank()) Text("📍 ${m.location}", style = MaterialTheme.typography.bodySmall)
                        Text(
                            if (m.eventId != null) "✓ În calendar" else "Neadăugată în calendar",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (m.eventId != null) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                        )
                    }
                    if (m.eventId != null) {
                        IconButton(onClick = { onOpen(m.eventId) }) {
                            Icon(Icons.Default.EventAvailable, contentDescription = "Deschide în calendar")
                        }
                    } else {
                        TextButton(onClick = { onAdd(i) }) { Text("Adaugă") }
                    }
                    IconButton(onClick = { onRemove(i) }) {
                        Icon(Icons.Default.Delete, contentDescription = "Șterge întâlnirea")
                    }
                }
            }
        }
    }
}

/** Afișare simplă de Markdown: titluri, liste cu puncte, **bold**. */
@Composable
private fun MarkdownText(md: String) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        md.lines().forEach { raw ->
            val line = raw.trimEnd()
            val trimmed = line.trimStart()
            val indent = (line.length - trimmed.length).coerceAtMost(8)
            when {
                trimmed.isEmpty() -> Spacer(Modifier.height(4.dp))
                trimmed.startsWith("#") -> Text(
                    bold(trimmed.trimStart('#').trim()),
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 8.dp)
                )
                trimmed.startsWith("- ") || trimmed.startsWith("* ") || trimmed.startsWith("• ") -> Row(
                    Modifier.padding(start = (indent * 6).dp)
                ) {
                    Text("•  ")
                    Text(bold(trimmed.substring(2)), style = MaterialTheme.typography.bodyMedium)
                }
                else -> Text(bold(trimmed), style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

private fun bold(s: String): AnnotatedString = buildAnnotatedString {
    s.split("**").forEachIndexed { i, part ->
        if (i % 2 == 1) withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(part) } else append(part)
    }
}
