package ro.notevocale.calendar

import android.Manifest
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.CalendarContract
import androidx.core.content.ContextCompat
import org.json.JSONArray
import ro.notevocale.data.Meeting
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.ZoneOffset
import java.util.TimeZone

/**
 * Adaugă evenimente direct în calendarul Google de pe telefon (prin CalendarContract).
 * Evenimentele se sincronizează automat cu Google Calendar.
 */
object CalendarHelper {

    fun hasPermission(ctx: Context): Boolean =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.WRITE_CALENDAR) == PackageManager.PERMISSION_GRANTED &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED

    /** Parsează răspunsul JSON al AI-ului în obiecte Meeting. */
    fun parseMeetings(json: String): List<Meeting> {
        val arr = runCatching { JSONArray(json) }.getOrNull() ?: return emptyList()
        val zone = ZoneId.systemDefault()
        return (0 until arr.length()).mapNotNull { i ->
            runCatching {
                val o = arr.getJSONObject(i)
                val allDay = o.optBoolean("toata_ziua", false)
                val startStr = o.getString("inceput")
                val title = o.optString("titlu").ifBlank { "Întâlnire" }
                if (allDay) {
                    // Evenimentele „toată ziua” se salvează în UTC, la miezul nopții.
                    val day = LocalDate.parse(startStr.take(10))
                    val start = day.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
                    val end = day.plusDays(1).atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
                    Meeting(title, start, end, true, o.optString("locatie"), o.optString("detalii"))
                } else {
                    val ldt = LocalDateTime.parse(startStr.take(16))
                    val minutes = o.optInt("durata_minute", 60).coerceIn(5, 24 * 60)
                    val start = ldt.atZone(zone).toInstant().toEpochMilli()
                    Meeting(title, start, start + minutes * 60_000L, false, o.optString("locatie"), o.optString("detalii"))
                }
            }.getOrNull()
        }
    }

    /** Găsește calendarul Google principal (sau alt calendar în care se poate scrie). */
    private fun findCalendarId(ctx: Context): Long? {
        val projection = arrayOf(
            CalendarContract.Calendars._ID,
            CalendarContract.Calendars.ACCOUNT_TYPE,
            CalendarContract.Calendars.IS_PRIMARY,
            CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL,
        )
        val sel = "${CalendarContract.Calendars.VISIBLE} = 1 AND " +
            "${CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL} >= ${CalendarContract.Calendars.CAL_ACCESS_CONTRIBUTOR}"
        var best: Long? = null
        var bestScore = -1
        runCatching { ctx.contentResolver.query(CalendarContract.Calendars.CONTENT_URI, projection, sel, null, null) }
            .getOrNull()?.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                val isGoogle = c.getString(1) == "com.google"
                val isPrimary = c.getInt(2) == 1
                val score = (if (isGoogle) 2 else 0) + (if (isPrimary) 1 else 0)
                if (score > bestScore) {
                    bestScore = score; best = id
                }
            }
        }
        return best
    }

    /** Inserează evenimentul și întoarce ID-ul lui, sau null dacă nu există calendar. */
    fun insert(ctx: Context, m: Meeting, sessionTitle: String): Long? {
        val calId = findCalendarId(ctx) ?: return null
        val values = ContentValues().apply {
            put(CalendarContract.Events.CALENDAR_ID, calId)
            put(CalendarContract.Events.TITLE, m.title)
            put(CalendarContract.Events.DESCRIPTION, buildString {
                if (m.details.isNotBlank()) appendLine(m.details)
                append("Adăugat automat din „$sessionTitle” (Note Vocale AI)")
            })
            if (m.location.isNotBlank()) put(CalendarContract.Events.EVENT_LOCATION, m.location)
            put(CalendarContract.Events.DTSTART, m.startMs)
            put(CalendarContract.Events.DTEND, m.endMs)
            put(CalendarContract.Events.ALL_DAY, if (m.allDay) 1 else 0)
            put(CalendarContract.Events.EVENT_TIMEZONE, if (m.allDay) "UTC" else TimeZone.getDefault().id)
            put(CalendarContract.Events.HAS_ALARM, 1)
        }
        val uri = ctx.contentResolver.insert(CalendarContract.Events.CONTENT_URI, values) ?: return null
        val eventId = ContentUris.parseId(uri)

        // Memento: cu 30 de minute înainte (sau cu o zi înainte la 9:00 pentru „toată ziua”).
        val reminder = ContentValues().apply {
            put(CalendarContract.Reminders.EVENT_ID, eventId)
            put(CalendarContract.Reminders.MINUTES, if (m.allDay) 15 * 60 else 30)
            put(CalendarContract.Reminders.METHOD, CalendarContract.Reminders.METHOD_ALERT)
        }
        runCatching { ctx.contentResolver.insert(CalendarContract.Reminders.CONTENT_URI, reminder) }
        return eventId
    }

    fun delete(ctx: Context, eventId: Long) {
        runCatching {
            ctx.contentResolver.delete(
                ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, eventId), null, null
            )
        }
    }

    /** Deschide evenimentul în aplicația Calendar. */
    fun openEvent(ctx: Context, eventId: Long) {
        val intent = Intent(Intent.ACTION_VIEW)
            .setData(ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, eventId))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { ctx.startActivity(intent) }
    }

    /** Variantă fără permisiune: deschide Calendarul cu evenimentul precompletat. */
    fun openInsertScreen(ctx: Context, m: Meeting) {
        val intent = Intent(Intent.ACTION_INSERT)
            .setData(CalendarContract.Events.CONTENT_URI)
            .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, m.startMs)
            .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, m.endMs)
            .putExtra(CalendarContract.EXTRA_EVENT_ALL_DAY, m.allDay)
            .putExtra(CalendarContract.Events.TITLE, m.title)
            .putExtra(CalendarContract.Events.DESCRIPTION, m.details)
            .putExtra(CalendarContract.Events.EVENT_LOCATION, m.location)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { ctx.startActivity(intent) }
    }
}
