package ro.notevocale.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import ro.notevocale.MainViewModel
import ro.notevocale.Screen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(vm: MainViewModel) {
    var aai by remember { mutableStateOf(vm.prefs.assemblyKey) }
    var claude by remember { mutableStateOf(vm.prefs.claudeKey) }
    var model by remember { mutableStateOf(vm.prefs.model) }
    var speakers by remember { mutableStateOf(vm.prefs.speakersExpected.takeIf { it > 0 }?.toString() ?: "") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Setări") },
                navigationIcon = {
                    IconButton(onClick = { vm.screen = Screen.Home }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Înapoi")
                    }
                }
            )
        }
    ) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().imePadding().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Transcriere + identificare vorbitori", style = MaterialTheme.typography.titleMedium)
            SecretField("Cheie API AssemblyAI", aai) { aai = it }
            Text(
                "Obții cheia gratuit (cu credit inițial) de pe assemblyai.com → Dashboard → API Keys.",
                style = MaterialTheme.typography.bodySmall
            )
            OutlinedTextField(
                value = speakers,
                onValueChange = { v -> speakers = v.filter { it.isDigit() }.take(2) },
                label = { Text("Număr de vorbitori (opțional)") },
                supportingText = { Text("Lasă gol pentru detectare automată. Dacă știi câți sunt, identificarea e mai precisă.") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Text("Rezumat AI", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 12.dp))
            SecretField("Cheie API Claude (Anthropic)", claude) { claude = it }
            Text(
                "Obții cheia de pe console.anthropic.com → API Keys.",
                style = MaterialTheme.typography.bodySmall
            )
            OutlinedTextField(
                value = model,
                onValueChange = { model = it },
                label = { Text("Model") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Button(
                onClick = {
                    vm.prefs.assemblyKey = aai
                    vm.prefs.claudeKey = claude
                    vm.prefs.model = model
                    vm.prefs.speakersExpected = speakers.toIntOrNull() ?: 0
                    vm.screen = Screen.Home
                },
                modifier = Modifier.fillMaxWidth().padding(top = 12.dp)
            ) { Text("Salvează") }
        }
    }
}

@Composable
private fun SecretField(label: String, value: String, onChange: (String) -> Unit) {
    var visible by remember { mutableStateOf(false) }
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = true,
        visualTransformation = if (visible) VisualTransformation.None else PasswordVisualTransformation(),
        trailingIcon = {
            IconButton(onClick = { visible = !visible }) {
                Icon(
                    if (visible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                    contentDescription = if (visible) "Ascunde" else "Arată"
                )
            }
        },
        modifier = Modifier.fillMaxWidth()
    )
}
