package ro.notevocale.data

enum class ProcStatus { PENDING, PROCESSING, DONE, ERROR }

/** O replică dintr-o înregistrare. speaker = "Vorbitor 1", "Vorbitor 2"... */
data class Utterance(val speaker: String, val text: String, val startMs: Long)

sealed class Item {
    abstract val id: String
    abstract val createdAt: Long

    /** Un segment de dialog înregistrat (prima înregistrare sau o continuare). */
    data class Recording(
        override val id: String,
        override val createdAt: Long,
        val filePath: String,
        val durationMs: Long,
        val status: ProcStatus,
        val utterances: List<Utterance> = emptyList(),
        val error: String? = null,
    ) : Item()

    /** O notă scrisă de utilizator. */
    data class Note(
        override val id: String,
        override val createdAt: Long,
        val text: String,
    ) : Item()
}

/** O întâlnire stabilită în discuție, extrasă de AI. eventId = ID-ul din calendarul telefonului. */
data class Meeting(
    val title: String,
    val startMs: Long,
    val endMs: Long,
    val allDay: Boolean,
    val location: String,
    val details: String,
    val eventId: Long? = null,
)

data class Session(
    val id: String,
    val title: String,
    val createdAt: Long,
    val items: List<Item>,
    val summary: String?,
    val meetings: List<Meeting> = emptyList(),
)
