package ro.notevocale.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import ro.notevocale.MainViewModel
import ro.notevocale.Screen
import ro.notevocale.data.Item
import ro.notevocale.rec.RecorderManager
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SessionListScreen(vm: MainViewModel) {
    val sessions by vm.sessions.collectAsStateWithLifecycle()
    val recState by vm.recState.collectAsStateWithLifecycle()
    val fmt = SimpleDateFormat("d MMMM yyyy, HH:mm", Locale("ro"))

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Note Vocale AI") },
                actions = {
                    IconButton(onClick = { vm.screen = Screen.Settings }) {
                        Icon(Icons.Default.Settings, contentDescription = "Setări")
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { vm.newSession() },
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("Discuție nouă") }
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            val recId = vm.recordingSessionId
            if (recState != RecorderManager.State.IDLE && recId != null) {
                Surface(
                    color = MaterialTheme.colorScheme.errorContainer,
                    modifier = Modifier.fillMaxWidth().clickable { vm.open(recId) }
                ) {
                    Text(
                        "● Înregistrare în curs – atinge pentru a reveni",
                        modifier = Modifier.padding(16.dp),
                        color = MaterialTheme.colorScheme.onErrorContainer
                    )
                }
            }

            if (sessions.isEmpty()) {
                Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                    Text(
                        "Nicio discuție încă.\nApasă „Discuție nouă” pentru a începe o înregistrare.",
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.bodyLarge
                    )
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 96.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(sessions, key = { it.id }) { s ->
                        val recs = s.items.count { it is Item.Recording }
                        val notes = s.items.count { it is Item.Note }
                        Card(onClick = { vm.open(s.id) }, modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(16.dp)) {
                                Text(s.title, style = MaterialTheme.typography.titleMedium)
                                Text(
                                    "${fmt.format(Date(s.createdAt))} · $recs înregistrări · $notes note",
                                    style = MaterialTheme.typography.bodySmall
                                )
                                if (s.summary != null) {
                                    Text(
                                        "✓ Rezumat AI generat",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.padding(top = 4.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
