package ro.notevocale.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Salvează fiecare discuție ca fișier JSON în memoria internă a aplicației. */
class SessionStore(context: Context) {
    private val dir = File(context.filesDir, "sessions").apply { mkdirs() }
    val audioDir = File(context.filesDir, "audio").apply { mkdirs() }

    fun loadAll(): List<Session> =
        (dir.listFiles { f -> f.extension == "json" } ?: emptyArray())
            .mapNotNull { f -> runCatching { fromJson(JSONObject(f.readText())) }.getOrNull() }
            .sortedByDescending { it.createdAt }

    fun save(s: Session) {
        val tmp = File(dir, "${s.id}.json.tmp")
        tmp.writeText(toJson(s).toString())
        tmp.renameTo(File(dir, "${s.id}.json"))
    }

    fun delete(s: Session) {
        File(dir, "${s.id}.json").delete()
        s.items.filterIsInstance<Item.Recording>().forEach { File(it.filePath).delete() }
    }

    private fun toJson(s: Session): JSONObject = JSONObject()
        .put("id", s.id)
        .put("title", s.title)
        .put("createdAt", s.createdAt)
        .put("summary", s.summary ?: JSONObject.NULL)
        .put("meetings", JSONArray().apply {
            s.meetings.forEach { m ->
                put(
                    JSONObject()
                        .put("title", m.title)
                        .put("startMs", m.startMs)
                        .put("endMs", m.endMs)
                        .put("allDay", m.allDay)
                        .put("location", m.location)
                        .put("details", m.details)
                        .put("eventId", m.eventId ?: JSONObject.NULL)
                )
            }
        })
        .put("items", JSONArray().apply {
            s.items.forEach { item ->
                put(
                    when (item) {
                        is Item.Note -> JSONObject()
                            .put("type", "note")
                            .put("id", item.id)
                            .put("createdAt", item.createdAt)
                            .put("text", item.text)

                        is Item.Recording -> JSONObject()
                            .put("type", "rec")
                            .put("id", item.id)
                            .put("createdAt", item.createdAt)
                            .put("filePath", item.filePath)
                            .put("durationMs", item.durationMs)
                            .put("status", item.status.name)
                            .put("error", item.error ?: JSONObject.NULL)
                            .put("utterances", JSONArray().apply {
                                item.utterances.forEach { u ->
                                    put(
                                        JSONObject()
                                            .put("speaker", u.speaker)
                                            .put("text", u.text)
                                            .put("startMs", u.startMs)
                                    )
                                }
                            })
                    }
                )
            }
        })

    private fun fromJson(o: JSONObject): Session {
        val arr = o.getJSONArray("items")
        val items = (0 until arr.length()).map { i ->
            val it = arr.getJSONObject(i)
            if (it.getString("type") == "note") {
                Item.Note(it.getString("id"), it.getLong("createdAt"), it.getString("text"))
            } else {
                val ua = it.optJSONArray("utterances") ?: JSONArray()
                Item.Recording(
                    id = it.getString("id"),
                    createdAt = it.getLong("createdAt"),
                    filePath = it.getString("filePath"),
                    durationMs = it.getLong("durationMs"),
                    status = ProcStatus.valueOf(it.getString("status")),
                    error = if (it.isNull("error")) null else it.getString("error"),
                    utterances = (0 until ua.length()).map { j ->
                        val u = ua.getJSONObject(j)
                        Utterance(u.getString("speaker"), u.getString("text"), u.getLong("startMs"))
                    }
                )
            }
        }
        return Session(
            id = o.getString("id"),
            title = o.getString("title"),
            createdAt = o.getLong("createdAt"),
            items = items,
            summary = if (o.isNull("summary")) null else o.getString("summary"),
            meetings = (o.optJSONArray("meetings") ?: JSONArray()).let { ma ->
                (0 until ma.length()).map { i ->
                    val m = ma.getJSONObject(i)
                    Meeting(
                        title = m.getString("title"),
                        startMs = m.getLong("startMs"),
                        endMs = m.getLong("endMs"),
                        allDay = m.optBoolean("allDay"),
                        location = m.optString("location"),
                        details = m.optString("details"),
                        eventId = if (m.isNull("eventId")) null else m.getLong("eventId"),
                    )
                }
            },
        )
    }
}
