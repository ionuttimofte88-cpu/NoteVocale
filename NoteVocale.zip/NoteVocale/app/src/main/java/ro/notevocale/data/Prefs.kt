package ro.notevocale.data

import android.content.Context

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("settings", Context.MODE_PRIVATE)

    var assemblyKey: String
        get() = sp.getString("aai_key", "") ?: ""
        set(v) = sp.edit().putString("aai_key", v.trim()).apply()

    var claudeKey: String
        get() = sp.getString("claude_key", "") ?: ""
        set(v) = sp.edit().putString("claude_key", v.trim()).apply()

    var model: String
        get() = (sp.getString("model", DEFAULT_MODEL) ?: DEFAULT_MODEL).ifBlank { DEFAULT_MODEL }
        set(v) = sp.edit().putString("model", v.trim()).apply()

    /** 0 = detectare automată a numărului de vorbitori. */
    var speakersExpected: Int
        get() = sp.getInt("speakers", 0)
        set(v) = sp.edit().putInt("speakers", v.coerceIn(0, 10)).apply()

    companion object {
        const val DEFAULT_MODEL = "claude-sonnet-5-5"
    }
}
